package com.nucleus.client;

import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;

import net.minecraft.client.Minecraft;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import com.nucleus.NucleusMod;

/**
 * Renders waypoints as simple block highlights that are
 * visible through walls (Gizmos with alwaysOnTop).
 * Text labels are optional via config.
 */
public final class MadoBrickWaypointRenderer {
	private MadoBrickWaypointRenderer() {
	}

	public static void register() {
		LevelRenderEvents.BEFORE_GIZMOS.register(context -> render());
	}

	private static void render() {
		Minecraft client = Minecraft.getInstance();
		if (client.level == null || client.player == null) {
			return;
		}
		if (!NucleusMod.CONFIG.madoBrickEnabled) {
			return;
		}
		if (!HollowsDetector.isInCrystalHollows()) {
			return;
		}
		// Cinematic: the jackpot owns the screen, waypoints stand down.
		if (JackpotAnimation.cinematicActive()) {
			return;
		}
		boolean hasMain = MadoBrickWaypoints.hasWaypoints();
		boolean hasCustom = MadoBrickWaypoints.hasCustom();
		if (!hasMain && !hasCustom) {
			return;
		}
		boolean throughWalls = NucleusMod.CONFIG.waypointsThroughWalls;
		boolean text = NucleusMod.CONFIG.waypointText;
		float outlineWidth = NucleusMod.CONFIG.waypointOutlineWidth;
		if (outlineWidth < 0.5f) {
			outlineWidth = 0.5f;
		} else if (outlineWidth > 10.0f) {
			outlineWidth = 10.0f;
		}

		Vec3 eye = client.player.getEyePosition();
		var temple = MadoBrickWaypoints.snapshot();
		var waypoints = new java.util.ArrayList<>(temple);
		waypoints.addAll(MadoBrickWaypoints.customSnapshot());

		for (var wp : waypoints) {
			if (!MadoBrickWaypoints.visibleFor(wp.index())) {
				continue;
			}
			// Etherwarp reaches 61 blocks: anything further renders dimmed.
			double dist = eye.distanceTo(Vec3.atCenterOf(wp.pos()));
			int color = MadoBrickWaypoints.colorFor(wp.index());
			if (NucleusMod.CONFIG.waypointDimBeyondEtherwarp && dist > 61.0) {
				color = dimColor(color, 0.35f);
			}
			int fill = withAlpha(color, 0x55);
			try {
				// Simple block highlight: outlined + slightly filled 1-block box.
				AABB box = new AABB(wp.pos()).inflate(0.02);
				var boxProps = Gizmos.cuboid(box, GizmoStyle.strokeAndFill(color, outlineWidth, fill));
				if (throughWalls) {
					boxProps.setAlwaysOnTop();
				}

				if (text) {
					String label = wp.label() + " §7(" + (int) dist + "m)";
					var textProps = Gizmos.billboardTextOverBlock(label, wp.pos(), 1, color, 1.0f);
					if (throughWalls) {
						textProps.setAlwaysOnTop();
					}
				}
			} catch (Exception e) {
				// Gizmos are only valid during level rendering; never crash the frame.
				NucleusMod.LOGGER.debug("Waypoint gizmo failed: {}", e.getMessage());
				return;
			}
		}

		// Jungle-only polylines WP1 -> WP2 -> WP3 (never custom waypoints).
		if (NucleusMod.CONFIG.templeLinkLines) {
			try {
				var ordered = new java.util.ArrayList<MadoBrickWaypoints.Waypoint>();
				for (var wp : temple) {
					if (wp.index() >= 0 && wp.index() <= 2
						&& MadoBrickWaypoints.visibleFor(wp.index())) {
						ordered.add(wp);
					}
				}
				ordered.sort(java.util.Comparator.comparingInt(MadoBrickWaypoints.Waypoint::index));
				for (int i = 0; i + 1 < ordered.size(); i++) {
					var a = ordered.get(i);
					var b = ordered.get(i + 1);
					int color = MadoBrickWaypoints.colorFor(a.index());
					if (NucleusMod.CONFIG.waypointDimBeyondEtherwarp
						&& eye.distanceTo(Vec3.atCenterOf(a.pos())) > 61.0
						&& eye.distanceTo(Vec3.atCenterOf(b.pos())) > 61.0) {
						color = dimColor(color, 0.35f);
					}
					var lineProps = Gizmos.line(
						Vec3.atCenterOf(a.pos()), Vec3.atCenterOf(b.pos()), color);
					if (throughWalls) {
						lineProps.setAlwaysOnTop();
					}
				}
			} catch (Exception e) {
				NucleusMod.LOGGER.debug("Waypoint link gizmo failed: {}", e.getMessage());
			}
		}
	}

	private static int withAlpha(int argb, int alpha) {
		return (alpha << 24) | (argb & 0x00FFFFFF);
	}

	/** Keeps alpha, scales RGB (for out-of-etherwarp-range dimming). */
	static int dimColor(int argb, float f) {
		int a = (argb >>> 24) & 0xFF;
		int r = (int) (((argb >> 16) & 0xFF) * f);
		int g = (int) (((argb >> 8) & 0xFF) * f);
		int b = (int) ((argb & 0xFF) * f);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}
}
